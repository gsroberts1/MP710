%%% Course URL
http://zoot.radiology.wisc.edu/~block/bme_530.html 

%%% 2D Matrix: create a simple
 %%  400x200 matrix with ones in the upper left corner
m=zeros(400,200);
m(1:50,1:100)=1;

%%% Image Display: some display options
imshow(m)
 % display the indeces in x and y
axis on
 % add the colorbar to display data range
colorbar
 % change the colormap
colormap(jet)
 % change colormap to grayscale intensity (our default)
colormap(gray)

%%% Loading 2D Data and Images
 % load a matlab baniary matrix (example.mat)
load example
 % what is the variable name of what we read in???
whos
imshow(ct_phantom)

 %Load  tif image
m_in = imread('example.tif','tif');
imshow(m_in)
 % To check details on an image
imfinfo('example.tif','tif')

%%% Create a 2D Gaussian function
 % running index from -1 to +1 (64x64 matrix)
ind = [-32:1:31]/32;
 % create two matricex x and y to represent variable parameters
[x,y] = meshgrid(ind,-1*ind);
 % calculate 2D Gaussian
z = exp(-pi/2*(x.^2+y.^2)/(.25.^2));
imshow(z)
colorbar

%%% 2D DFT of the Gaussian
Z=fftshift(fft2(fftshift(z)));
 % check all variables in workspace
whos
 % display real and imaginary components in images
figure
 % display with default scaling [0..1]
imshow(real(Z))
 % display with scaling [min ... max]
imshow(real(Z),[])
colorbar
figure
imshow(imag(Z),[])
colorbar

%%% Zero-Filling
 % create matrix 256x256 with all zero entries
z_zf = zeros(256);
 % fill the center with the original 64x64 matrix
z_zf(97:160,97:160) = z;
Z_ZF = fftshift(fft2(fftshift(z_zf)));
figure
imshow(abs(Z_ZF),[])
colorbar
figure
imshow(angle(Z_ZF),[])
colorbar


%%% Voxel shifting
z_s = zeros(256);
 % shift the image: 5 voxels up and 2 voxels left
z_s(92:155,95:158) = z;
Z_S = fftshift(fft2(fftshift(z_s)));
figure
imshow(abs(Z_S),[])
colorbar
figure
imshow(angle(Z_S),[])
colorbar
